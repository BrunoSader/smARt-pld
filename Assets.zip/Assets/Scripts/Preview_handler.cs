﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Preview_handler : MonoBehaviour
{

    private GameObject preview;
    private GameObject anim;
    private GameObject showbutton;
    private GameObject hidebutton;
    public go_to goTo;

    public void Start()
    {
        //Finding preview (3D model)
        GameObject previewPopUpParent = GameObject.Find("Preview Container");
        Debug.Log("found container");
        Transform[] trsP = previewPopUpParent.GetComponentsInChildren<Transform>(true);
        foreach (Transform t in trsP)
        {
            Debug.Log("iterating");
            if (t.name == "Preview PopUp")
            {
                Debug.Log("found preview");
                preview = t.gameObject;
            }
        }

        //Finding hide button
        GameObject showButtonParent = GameObject.Find("Preview Buttons");
        Debug.Log("found container");
        Transform[] trsB = showButtonParent.GetComponentsInChildren<Transform>(true);
        foreach (Transform t in trsB)
        {
            Debug.Log("iterating");
            if (t.name == "HideButton")
            {
                Debug.Log("found button");
                hidebutton = t.gameObject;
            }
        }

        //Finding Show Button and animation
        showbutton = GameObject.Find("ShowButton");
        anim = GameObject.Find("Preview Animation");

    }


    public void ShowPreview()
    {
        //hiding animation and show button
        showbutton.SetActive(false);
        anim.SetActive(false);

        //Showing popup and hide button
        preview.SetActive(true);
        hidebutton.SetActive(true);
    }

    public void HidePreview()
    {
        //hiding preview and hide button
        hidebutton.SetActive(false);
        preview.SetActive(false);

        //Showing anim and show button
        anim.SetActive(true);
        showbutton.SetActive(true);
    }
}

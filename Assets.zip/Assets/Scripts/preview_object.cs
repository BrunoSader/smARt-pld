﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class preview_object : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {
        if (Input.touchCount == 1)
        {
            Touch t = Input.GetTouch(0);

            if (Vector3.Dot(transform.up, Vector3.up) >= 0)
            {
                transform.Rotate(transform.up, -0.25f*Vector3.Dot(t.deltaPosition, Camera.main.transform.right), Space.Self);
            }
            else
            {
                transform.Rotate(transform.up, 0.25f*Vector3.Dot(t.deltaPosition, Camera.main.transform.right), Space.Self);
            }

            transform.Rotate(Camera.main.transform.right, 0.3f*Vector3.Dot(t.deltaPosition, Camera.main.transform.up), Space.World) ;
        }
    }
}

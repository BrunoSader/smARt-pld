﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class final_scene : MonoBehaviour
{
    private GameObject preview;
    private GameObject modelName;

    // Start is called before the first frame update
    void Start()
    {
        //Find corresponding name and animation
        GameObject nameParent = GameObject.Find("Model Names");
        Debug.Log("found name container");
        Transform[] trsN = nameParent.GetComponentsInChildren<Transform>(true);
        foreach (Transform t in trsN)
        {
            Debug.Log("iterating");
            if (t.name == Globals.name)
            {
                Debug.Log("found name image");
                modelName = t.gameObject;
            }
        }

        GameObject previewParent = GameObject.Find("Preview Container");
        Debug.Log("found preview container");
        Transform[] trsP = previewParent.GetComponentsInChildren<Transform>(true);
        foreach (Transform t in trsP)
        {
            Debug.Log("iterating");
            if (t.name == Globals.name + " Animation")
            {
                Debug.Log("found preview");
                preview = t.gameObject;
            }
        }

        Debug.Log(Globals.name);
        if(preview != null) {preview.SetActive(true);}
        if (modelName != null) {modelName.SetActive(true);}
    }

    public void quitApp()
    {
        Debug.Log("Quitting app");
        Application.Quit();
    }
}

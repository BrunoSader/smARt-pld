﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using System.IO;
using System.Linq;

using Vuforia;
using System.Collections.Generic;

public class MyQRTrackableEventHandler : DefaultTrackableEventHandler {
    
    public string scene {get; set;}

    protected override void OnTrackingFound() {
        base.OnTrackingFound ();
        go_to scene_chng =  (new GameObject("scenechng_obj")).AddComponent<go_to>();
		//scene_chng.fixe = Resources.Load<UnityEngine.UI.Image>("Assets/UI elements/Main menu/loading.png");
        scene_chng.gotoscene(scene); // needs to be changed to gotoscene
	}

   protected override void OnTrackingLost() {
        base.OnTrackingLost ();
        //put logic here
    }
}

public class Item
{
    public int id {get;set;}
    public string QR_name {get; set;}
    public string first_scene {get; set;}
}

public class load_QR : MonoBehaviour
{
	/*
    public List<Item> LoadJson()
    {
        using (StreamReader r = new StreamReader("Assets/Documents/QR.json"))
        {
            string json = r.ReadToEnd();
            List<Item> items = JsonConvert.DeserializeObject<List<Item>>(json);
			return items;
        }
        
    }*/

	public GameObject augmentationObject = null;  // allows to add an AR object on top
	public string dataSetName = "smARt";  

	// Use this for initialization
	void Start()
	{
		//LoadQRtoJson();
		Debug.Log("<color=red>In start QR</color>");
		VuforiaARController.Instance.RegisterVuforiaStartedCallback(LoadDataSet);
		VuforiaARController.Instance.UnregisterVuforiaStartedCallback(LoadDataSet);
	}

	void LoadDataSet()
	{
		Debug.Log("<color=red>In Load QR</color>");
		ObjectTracker objectTracker = TrackerManager.Instance.GetTracker<ObjectTracker>();
		
		DataSet dataSet = objectTracker.CreateDataSet();
		
		if (dataSet.Load(dataSetName)) {
			
			objectTracker.Stop();  // stop tracker so that we can add new dataset

			if (!objectTracker.ActivateDataSet(dataSet)) {
				// Note: ImageTracker cannot have more than 100 total targets activated
				Debug.Log("<color=yellow>Failed to Activate DataSet: " + dataSetName + "</color>");
			}

			if (!objectTracker.Start()) {
				Debug.Log("<color=yellow>Tracker Failed to Start.</color>");
			}

			int counter = 0;

			IEnumerable<TrackableBehaviour> tbs = TrackerManager.Instance.GetStateManager().GetTrackableBehaviours();
			foreach (TrackableBehaviour tb in tbs) {
				if (tb.name == "New Game Object") {
					//string scene = element.first_scene;
					// change generic name to include trackable name
					tb.gameObject.name = tb.TrackableName;
					++counter;
					// add additional script components for trackable
					tb.gameObject.AddComponent<MyQRTrackableEventHandler>();
					tb.gameObject.AddComponent<TurnOffBehaviour>();

					tb.gameObject.GetComponent<MyQRTrackableEventHandler>().scene = tb.TrackableName.Replace("QRCode", "") + "_scene-1";
				}
			}
		} else {
			Debug.LogError("<color=yellow>Failed to load dataset: '" + dataSetName + "'</color>");
		}
	}

	/*
	void LoadQRtoJson()
	{
        List<Item> _data = new List<Item>();

		ObjectTracker objectTracker = TrackerManager.Instance.GetTracker<ObjectTracker>();
		
		DataSet dataSet = objectTracker.CreateDataSet();
		
		if (dataSet.Load(dataSetName)) {
			
			objectTracker.Stop();  // stop tracker so that we can add new dataset

			if (!objectTracker.ActivateDataSet(dataSet)) {
				// Note: ImageTracker cannot have more than 100 total targets activated
				Debug.Log("<color=yellow>Failed to Activate DataSet: " + dataSetName + "</color>");
			}

			if (!objectTracker.Start()) {
				Debug.Log("<color=yellow>Tracker Failed to Start.</color>");
			}

			int counter = 0;

			IEnumerable<TrackableBehaviour> tbs = TrackerManager.Instance.GetStateManager().GetTrackableBehaviours();
			foreach (TrackableBehaviour tb in tbs) {
				if (tb.name == "New Game Object") {
                    _data.Add(new Item()
                    {
                        id = ++counter,
                        QR_name = tb.TrackableName,
                        first_scene = tb.TrackableName.Replace("QRCode", "") + "_scene-1"
                    });
				}
			}
            using (StreamWriter file = File.CreateText("Assets/Documents/QR.json"))
            {
                JsonSerializer serializer = new JsonSerializer();
                serializer.Serialize(file, _data);
            }
			objectTracker.Start();
		} else {
			Debug.LogError("<color=yellow>Failed to load dataset: '" + dataSetName + "'</color>");
		}
	} */
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class target_found_test : MonoBehaviour
{
    public void target_found()
        {
            Debug.Log("target found");
        }
}

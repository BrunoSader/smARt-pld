﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class home_button : MonoBehaviour
{
    private GameObject popUp;
    public go_to goTo;

    public void ShowLeavePopUp()
    {
        //Finding popup
        GameObject popUpParent = GameObject.Find("PopUp");
        Debug.Log("found parent");
        Transform[] trs = popUpParent.GetComponentsInChildren<Transform>(true);
        foreach (Transform t in trs)
        {
            Debug.Log("iterating");
            if (t.name == "Leave PopUp")
            {
                Debug.Log("found popup");
                popUp = t.gameObject;
            }
        }

        //Showing popup
        popUp.SetActive(true);
    }

    public void HideLeavePopUp()
    {
        popUp.SetActive(false);
    }
    public void goHome ()
    {
        if(popUp.activeInHierarchy)
        {
            popUp.SetActive(false);
        }
        Debug.Log("calling goto");
        goTo.gotoscene("scene-0");
    }

    public void goHomeFinal()
    {
        Debug.Log("calling goto");
        goTo.gotoscene("scene-0");
    }
}

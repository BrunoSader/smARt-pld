﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using System.IO;
using System.Linq;
using System;

using Vuforia;
using System.Collections.Generic;

/// Can be used everywhere
public static class Globals {
    public static int found = 1;
	public static string name {get; set;}
	public static int counter = 0;
}

public class Coordinate{
	public int id {get; set;}
	public Vector3 delta {get; set;}
	public Vector3 rotation {get; set;}
	public Vector3 scale {get; set;}
}

public class MyARTrackableEventHandler : DefaultTrackableEventHandler {

    public GameObject currentStep {get; set;}
	public Material ourDepthMask;

    protected override void OnTrackingFound() {
        base.OnTrackingFound ();
        Debug.Log("<color=blue> Counter "+Globals.counter+"</color>");
        Debug.Log("<color=green> Found "+Globals.name+"Step"+(Globals.found)+"</color>");
        Globals.found++;

        if(Globals.found < Globals.counter) {
            GameObject nextStep = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(x=>x.name.Equals(Globals.name+"Step"+(Globals.found)));
            nextStep.AddComponent<DefaultTrackableEventHandler>();
            currentStep.SetActive(false);
            Destroy(currentStep.GetComponent<DefaultTrackableEventHandler>());
			Destroy(nextStep.GetComponent<MyARTrackableEventHandler>());
			currentStep = nextStep; // current step is now step i+1
			nextStep = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(x=>x.name.Equals(Globals.name+"Step"+(Globals.found+1))); // next step is now step i+2 (think of it as nextnextstep)
			nextStep.AddComponent<MyARTrackableEventHandler>();
			nextStep.GetComponent<MyARTrackableEventHandler>().currentStep = currentStep;
            nextStep.SetActive(true);
        } else {
        	Debug.Log("<color=yellow> LEAVING </color>");
			Debug.Log("<color=blue> Counter "+Globals.counter+"</color>");
        	Debug.Log("<color=green> Found "+Globals.name+"Step"+(Globals.found)+"</color>");
			go_to scene_chng =  (new GameObject("scenechng_obj")).AddComponent<go_to>();
			scene_chng.gotoscene("scene-final"); //needs to change to go to "scene-final"
        }
    }

        protected override void OnTrackingLost() {
        base.OnTrackingLost ();
        //put logic here
    }
}


public class scene_AR_manager : MonoBehaviour
{
	public List<GameObject> augmentationObjects = null;  // allows to add an AR object on top
	public string dataSetName;

	// Use this for initialization
	void Start()
	{
		Debug.Log("<color=red>In start scene manager</color>");
        Globals.name = SceneManager.GetActiveScene().name.Replace("_scene-1", "");
        dataSetName = Globals.name+"Training";
		VuforiaARController.Instance.RegisterVuforiaStartedCallback(LoadARDataSet);
		VuforiaARController.Instance.UnregisterVuforiaStartedCallback(LoadARDataSet);
	}

	void LoadARDataSet()
	{
		Debug.Log("<color=red>In Load AR</color>");
		ObjectTracker objectTracker = TrackerManager.Instance.GetTracker<ObjectTracker>();

		DataSet dataSet = objectTracker.CreateDataSet();

		if (dataSet.Load(dataSetName)) {

			objectTracker.Stop();  // stop tracker so that we can add new dataset

			if (!objectTracker.ActivateDataSet(dataSet)) {
				// Note: ImageTracker cannot have more than 100 total targets activated
				Debug.Log("<color=yellow>Failed to Activate DataSet: " + dataSetName + "</color>");
			}

			if (!objectTracker.Start()) {
				Debug.Log("<color=yellow>Tracker Failed to Start.</color>");
			}

			/*//Read fichier de coordonnees
			List<Coordinate> coordinates = new List<Coordinate>();
			string line = "";
			string path = "Assets/Documents/Coordinates.txt";
			StreamReader reader = new StreamReader(path);
			using (reader){
				int k = 0;
				while(line != null){
					Coordinate coordinate = new Coordinate();
					line = reader.ReadLine();
					if (line != null){
						string[] entries = line.Split(',');
						if (entries.Length > 0){
							coordinate.id = k; // = Vector3(Int32.Parse(entries[0]) idem mais moins de lecture
                            coordinate.delta = new Vector3(Int32.Parse(entries[1])/100f, Int32.Parse(entries[2])/100f, Int32.Parse(entries[3]));
                            coordinate.rotation = new Vector3(Int32.Parse(entries[4]), Int32.Parse(entries[5]), Int32.Parse(entries[6]));
                            coordinate.scale = new Vector3(Int32.Parse(entries[7])/100f, Int32.Parse(entries[8])/100f, Int32.Parse(entries[9])/100f);
						}
					}
					coordinates.Add(coordinate);
					k++;
				}
				reader.Close();
			}*/

			IEnumerable<TrackableBehaviour> tbs = TrackerManager.Instance.GetStateManager().GetTrackableBehaviours();
			foreach (TrackableBehaviour tb in tbs) {
				if (tb.name == "New Game Object" && tb.TrackableName !="emulator_ground_plane") {
					//string scene = element.first_scene;
					// change generic name to include trackable name
					tb.gameObject.name = tb.TrackableName;
					++Globals.counter;
					// add additional script components for trackable
					if(tb.TrackableName != (Globals.name+"Step1") && tb.TrackableName != (Globals.name+"Step2")) {
                   		tb.gameObject.SetActive(false);
					}
					if(tb.TrackableName == (Globals.name+"Step2")) {
						tb.gameObject.AddComponent<MyARTrackableEventHandler>();
						tb.gameObject.GetComponent<MyARTrackableEventHandler>().currentStep = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(x=>x.name.Equals(Globals.name+"Step1"));
					}
					if(tb.TrackableName == (Globals.name+"Step1")) {
						tb.gameObject.AddComponent<DefaultTrackableEventHandler>();
					}
					tb.gameObject.AddComponent<TurnOffBehaviour>();
					GameObject augmentation = (GameObject)GameObject.Instantiate(Resources.Load<GameObject>("3DModels/"+Globals.name+"Obj"+Globals.counter));
					augmentation.transform.parent = tb.gameObject.transform;
					augmentation.transform.localPosition = new Vector3(0f, 0f, 0f);
					augmentation.transform.localRotation = Quaternion.identity;
					augmentation.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
					// augmentation.transform.localPosition = coordinates[Globals.counter-1].delta;
					// augmentation.transform.localRotation = Quaternion.Euler(coordinates[Globals.counter-1].rotation);
					// augmentation.transform.localScale = coordinates[Globals.counter-1].scale;
					augmentation.gameObject.SetActive(true);

					//Occlusion
					GameObject occlusion = (GameObject)GameObject.Instantiate(Resources.Load<GameObject>("3DModels/"+Globals.name+"Build"+Globals.counter));
					occlusion.transform.parent = tb.gameObject.transform;
					occlusion.transform.localPosition = new Vector3(0f, 0f, 0f);
					occlusion.transform.localRotation = Quaternion.identity;
					occlusion.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
					occlusion.gameObject.SetActive(true);
					//Probleme avec DepthMask - not found
					Material ourDepthMask = new Material( Shader.Find("DepthMask") );
					// occlusion.GetComponent<MeshRenderer>().material = ourDepthMask;

					Renderer[] children = occlusion.GetComponentsInChildren<Renderer>();
					foreach (Renderer rend  in children) {
						Material[] mats = new Material[rend.materials.Length];
						for (int j = 0; j < rend.materials.Length; j++) {
							mats[j] = ourDepthMask;
						}
						rend.materials = mats;
					}
				}
			}
		} else {
			Debug.LogError("<color=yellow>Failed to load dataset: '" + dataSetName + "'</color>");
		}
	}
}

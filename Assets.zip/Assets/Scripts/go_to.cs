﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class go_to : MonoBehaviour
{
    private Sprite sprite;

    public void gotoscene (string scene)
    {
        StartCoroutine(loading(scene));
    }

    private IEnumerator loading(string scene)
    {
        GameObject chargement = Resources.FindObjectsOfTypeAll<GameObject>().FirstOrDefault(x=>x.name.Equals("Loading PopUp"));

        sprite = Resources.Load<Sprite>("UIelements/loading");
        Debug.Log(sprite.name);

        chargement.GetComponent<Image>().sprite = sprite;

        chargement.SetActive(true);
		Debug.Log("FIXE!!!!!");
		Debug.Log(chargement);

        AsyncOperation chargementScene1 = SceneManager.LoadSceneAsync(scene);

        yield return new WaitForEndOfFrame();
    }

    public void debug_switch_scene (string scene)
    {
        SceneManager.LoadScene(scene);
    }
}
